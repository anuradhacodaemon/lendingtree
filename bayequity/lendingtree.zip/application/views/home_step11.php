<div class="clearfix" id="container1">
    <div class="" id="container">
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2 col-xs-12">
                <div class="form-main home-loan clearfix">
                    <h1 class="text-head">Did you close on your mortgage on or before May 31, 2009?</h1>
                    <!--<a href="" class="disclosure-sec">Disclosures</a>-->
                    <div class="clearfix"></div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="offer-cont">
                            <a href="javascript:void(0);" onclick="home_step111(1)">
                                <button class="offer-circ">
                                    <div class="outer-circ">
                                        <div class="inner-bevel">
                                            <div class="second-bevel">
                                                <div class="offer-img offer-yes_check"></div>
                                                <p class="title">Yes</p>
                                            </div>
                                        </div>
                                    </div>
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="offer-cont">
                            <a href="javascript:void(0);" onclick="home_step111(2)">
                                <button class="offer-circ">
                                    <div class="outer-circ">
                                        <div class="inner-bevel">
                                            <div class="second-bevel">
                                                <div class="offer-img offer-no_slash"></div>
                                                <p class="title">No</p>
                                            </div>
                                        </div>
                                    </div>
                                </button>
                            </a>
                        </div>
                    </div>
                  
                </div>
            </div>
            <div class="disclosure">
                <i class="fa fa-lock"></i>&nbsp;&nbsp;Privacy secured&nbsp;&nbsp;|&nbsp;&nbsp;
                <a id="promodisclosure" rel="nofollow" class="disclosures-link" href="">Advertising Disclosures</a>
            </div>
        </div>
    </div>
</div>
<!-- Banner ends here -->


<footer>
    <div class="pull-right">
culoanportal   </div>
    <div class="clearfix"></div>
</footer>
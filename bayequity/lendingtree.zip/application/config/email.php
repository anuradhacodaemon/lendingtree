<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'in.mailjet.com';
$config['smtp_port'] = '25';
$config['smtp_user'] = '0cfe4bcb34b75be431f70ec4a8e2d7c0';
$config['smtp_pass'] = '4477c06d14710371d226cbe4d93fb993';
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['newline'] = "\r\n";

